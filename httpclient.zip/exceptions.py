class DecodeError(Exception):
    pass


class ByteFloodError(Exception):
    pass


class BytesDecodeError(Exception):
    pass


