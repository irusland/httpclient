class DecodeError(Exception):
    pass


class ImageRepresentationError(Exception):
    pass


class BytesDecodeError(Exception):
    pass


